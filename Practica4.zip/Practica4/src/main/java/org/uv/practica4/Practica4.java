/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package org.uv.practica4;

/**
 *
 * @author Yolotzin Groth Hdez
 */
public class Practica4 {

    public static void main(String[] args) {
       EmpleadoDao dao= new EmpleadoDao();
       EmpleadoPojo empleadoPojo=new EmpleadoPojo();
       
       empleadoPojo.setClave(100);
       empleadoPojo.setNombre("Gabriel 111");
       empleadoPojo.setDireccion("Av.111");
       empleadoPojo.setTelefono("1111");
       
       boolean r=dao.guardar(empleadoPojo);
       if (r)
           System.out.println("Se guardo");
       else
             System.out.println("Error");
    }
}
