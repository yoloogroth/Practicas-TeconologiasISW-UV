/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.uv.practica4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yolotzin Groth Hdez
 */
public class ConexionDB {
    private static ConexionDB conexionDB=null;
    public static ConexionDB getIntance (){
        if(conexionDB==null)
            conexionDB=new ConexionDB();
        return conexionDB;
        
    }
    private String url="jdbc:postgresql://localhost:5433/crudp2"; //patron singletonm sirve para tener una unica instancia en la comexion de base de datos
    private Connection con=null;
     public ConexionDB(){
        try {
            Class.forName("org.postgresql.Driver");
            con=DriverManager.getConnection(url,"Postgres","12345");
            Logger.getLogger(ConexionDB.class.getName()).log(Level.INFO, "Se conecto a la BD");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        
     }
     public boolean execute (String sql){ // genera errores o indicadores de exccesiones
         
        try {
            Statement st = con.createStatement();
            st.execute(sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        
       return false;
         
        }  
     }
     public ResultSet select (String sql){
         try{
             Statement st=con.createStatement();
             ResultSet res=st.executeQuery(sql);
             return res;
         }catch (SQLException ex){
              Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        
       return null;
             
         }
     }
}
