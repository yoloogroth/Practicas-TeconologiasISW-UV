/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.uv.practica4;

import java.util.List;

/**
 *
 * @author Yolotzin Groth Hdez
 */
    public class EmpleadoDao {
    private ConexionDB con=null;
    public EmpleadoDao() {
            con=ConexionDB.getIntance();
    }
        
        public boolean guardar(EmpleadoPojo e){
            String sql="insert into empleado (clave,nombre, direccion, telefono)"
                    + " values('"+ e.getClave()+"','"+ e.getNombre()+ "',"
                    +"'" + e.getDireccion()+ "','" + e.getTelefono() + "')";
       boolean res=con.execute(sql);
       return true;
       
    }
     public boolean eliminar (int id){
    return true;
    }
    public boolean modificar(EmpleadoPojo e){
    return true;
    }
    public EmpleadoPojo buscarByid(int id){
    return null;
    }
    public List<EmpleadoPojo> buscarTodos(){
        return null;
    }
    }
