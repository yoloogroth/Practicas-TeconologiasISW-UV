/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package org.uv.practica2;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yolotzin Groth Hdez
 */
public class Practica2 {

    public static void main(String[] args) {
        //ConexionDB con = ConexionDB.getIntance();
        ConexionDB.getIntance();
        /*
        String sql = "insert into empleado (clave, nombre, direccion, telefono) "
                + "values"
                + "('05','Arturo','av.123','7654321' )";
         boolean res = con.excute(sql);
         if (res)
             Logger.getLogger("Principal").log(Level.INFO,"se guardo");
         else
             Logger.getLogger("Principal").log(Level.SEVERE,"Error");
             */
             
    }
}
