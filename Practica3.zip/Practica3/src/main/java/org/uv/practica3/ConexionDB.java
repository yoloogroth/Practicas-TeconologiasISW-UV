/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.uv.practica3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yolotzin Groth Hdez
 */
public class ConexionDB {
    private static ConexionDB conexionDB=null;
    private Connection con=null;
    private String URL="jdbc:postgresql://localhost:5432/crudp2"; 
    private String USER="postgres";
    private String PASSWORD="12345";
    
    private ConexionDB(){
        try {
           Class.forName("org.postgresql.Driver");
           con=DriverManager.getConnection(URL, USER, PASSWORD);
           Logger.getLogger(ConexionDB.class.getName()).log(Level.INFO, "Se conecto a la BD");
       } catch (ClassNotFoundException | SQLException ex) {
           Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    
    public static ConexionDB getIntance (){
        if(conexionDB==null)
            conexionDB=new ConexionDB();
        return conexionDB;
    }    
    
    public boolean executeCreate (String sql){ // genera errores o indicadores de exccesiones         
        try {
            Statement st = con.createStatement();
            st.execute(sql);
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);        
            return false;
        }  
    }
    
    public ResultSet executeRead(String sql){
        try {
            Statement stmt = con.createStatement();
            // leer secuencia sql
            ResultSet rs = stmt.executeQuery(sql);
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
}
