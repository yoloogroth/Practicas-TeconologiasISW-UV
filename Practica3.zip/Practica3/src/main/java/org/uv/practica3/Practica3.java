/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package org.uv.practica3;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Yolotzin Groth Hdez
 */
public class Practica3 {

    public static void main(String[] args) {
        try {
            ConexionDB con= ConexionDB.getIntance();
            
            /*
            String sql = "insert into empleado (clave, nombre, direccion, telefono) "
            + "values"
            + "('01','Irais mi bebita fiu fiu','av.123','7654321' )";
            boolean res = con.executeCreate(sql);
            if (res)
            Logger.getLogger("Principal").log(Level.INFO,"se guardo");
            else
            Logger.getLogger("Principal").log(Level.SEVERE,"Error");
               */
            
            
            String sql = "select nombre from empleado where clave = '01'";
            
            ResultSet res = con.executeRead(sql);
            
            while(res.next()){
                String nombre = res.getString("nombre");
                System.out.println("Nombre: "+nombre);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Practica3.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
