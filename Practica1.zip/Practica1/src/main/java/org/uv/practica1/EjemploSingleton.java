/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.uv.practica1;

/**
 *
 * @author Yolotzin Groth Hdez
 */
public class EjemploSingleton { //ejemplo de creacion 
    
    private static EjemploSingleton ejemploSingleton=null;
    public static EjemploSingleton getInstance(){
        if (ejemploSingleton==null)
            ejemploSingleton=new EjemploSingleton();
        return ejemploSingleton;
    }
    private EjemploSingleton(){
        
    }
    public void imprimir(){
        System.out.println("Hola mundo");
    }
   
}
