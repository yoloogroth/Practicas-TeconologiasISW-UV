/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package org.uv.practica1;

/**
 *
 * @author Yolotzin Groth Hdez
 */
public class Practica1 {

    public static void main(String[] args) {
     // EjemploSingleton obj=new EjemploSingleton(); //intancia 
      
      //System.out.println(obj); 
                //obj=new EjemploSingleton();
                
      // System.out.println(obj);
      
      EjemploSingleton obj= EjemploSingleton.getInstance();
      
      System.out.println(obj);
      obj=EjemploSingleton.getInstance();
      
      System.out.println(obj);
      
    }
}
